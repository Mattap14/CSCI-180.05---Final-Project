package app.rest.controllers;

import java.util.List;

import javax.ws.rs.FormParam;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.QueryParam;
import javax.ws.rs.core.MediaType;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import app.components.NotificationManager;
import app.entity.Notification;
import app.entity.Order;

@Component
@Path("/notification")
public class NotificationController {
	
	@Autowired
	NotificationManager nm;
	
	@GET
	@Path("/getByStudent")
	@Produces(MediaType.APPLICATION_JSON)
	public List<Notification> getNotifications(@QueryParam("studentPk") Long studentPk) {
		return nm.getAllNotifications(studentPk);
	}
	
	@POST
	@Path("updateStatus")
	@Produces(MediaType.APPLICATION_JSON)
	public Order updateOrderStatus
				(@FormParam("orderPk") Long orderPk,
				 @FormParam("status") String status) 
	{
		
		return nm.updateOrderStatus(orderPk, status);
	}

}
