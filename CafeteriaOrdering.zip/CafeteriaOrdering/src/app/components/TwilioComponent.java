package app.components;

import java.util.Base64;

import org.springframework.stereotype.Component;

import retrofit2.Call;
import retrofit2.Response;
import retrofit2.Retrofit;
import retrofit2.converter.gson.GsonConverterFactory;

@Component
public class TwilioComponent {
	
	static String msgsid = "MG9ed621bcaf657c21bdf9de98647efc3c";
	
	static String acctId =  "AC7d52d386c10c7c41a3e653d53fcd1b50";
	static String creds = "910931f86fa37a5766293aed1d198fcd";

	static String url = "http://localhost:9997/fake_twilio/send";
			
	public TwilioReply sendSMS(String cellphoneNumber, String message) throws Exception{
		Retrofit retrofit = new Retrofit.Builder()
				.baseUrl("http://localhost:9997/")
				.addConverterFactory(GsonConverterFactory.create())
		        .build();
		
		byte[] encodedAuth= Base64.getEncoder().encode((acctId+":"+creds).getBytes());
		final String authorization = "Basic " + new String(encodedAuth);
		
		TwilioRequests req = retrofit.create(TwilioRequests.class);
		Call<TwilioReply> call = req.SMS(
				cellphoneNumber, 		
				msgsid,
				message,
				authorization,
				url);
		
		Response<TwilioReply> resp = call.execute();
		
		return resp.body();
		
	}

	

}
