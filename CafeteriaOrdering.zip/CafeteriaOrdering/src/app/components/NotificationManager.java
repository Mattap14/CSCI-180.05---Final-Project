package app.components;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import app.entity.Notification;
import app.entity.Order;
import app.entity.Student;
import app.repository.NotificationRepository;
import app.repository.OrderRepository;
import app.repository.StudentRepository;

@Component
public class NotificationManager {
	
	@Autowired
	NotificationRepository nr;
	
	@Autowired
	StudentRepository sr;
	
	@Autowired
	OrderRepository or;
	
	public List<Notification> getAllNotifications(Long studentPk){
		Student selectedStudent = sr.findBystudentPk(studentPk);
		List<Notification> notificationList = new ArrayList<>();
		if(selectedStudent != null) {
			for (Notification n : nr.findAll()) {
				if(n.getStudentPk()==selectedStudent.getStudentPk()) {
					notificationList.add(n);
				}
			}
		}	
		return notificationList;
	}
	
	public Order updateOrderStatus(Long orderPk, String status) {
		Order selectedOrder = or.findByorderPk(orderPk);
		if(selectedOrder != null) {
			selectedOrder.setStatus(status);
		}
		return selectedOrder;
	}

}
