package app.components;


import java.time.LocalDateTime;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import app.DTO.OrderDTO;
import app.DTO.OrderItemDTO;
import app.entity.Notification;
import app.entity.Order;
import app.entity.OrderItem;
import app.entity.Student;
import app.repository.NotificationRepository;
import app.repository.OrderItemRepository;
import app.repository.OrderRepository;
import app.repository.StudentRepository;
import retrofit2.Call;
import retrofit2.Response;
import retrofit2.Retrofit;
import retrofit2.converter.gson.GsonConverterFactory;

@Component
public class OrderManager {
	
	@Autowired
	OrderRepository or;
	
	@Autowired
	OrderItemRepository oir;
	
	@Autowired
	StudentRepository sr;
	
	@Autowired
	NotificationRepository nr;
	
	@Autowired
	private TwilioComponent twilioComponent;
	
	public List<Order> getAllOrders() {
		return or.findAll();	
	}
	
	public Order getOrder(Long orderPk) {
		return or.findByorderPk(orderPk);
	}
	
	public List<OrderItem> getAllOrderItems(Long orderPk){
		return oir.findByorderPk(orderPk);
	}
	
	public List<Order> getOrdersbyStudent(Long studentPk){
		return or.findByStudentPk(studentPk);
	}
	
	public TwilioReply placeOrder(OrderDTO orderDTO) throws Exception{
		Long selectedStudentpk = orderDTO.getStudentPk();
		Student selectedStudent = sr.findBystudentPk(selectedStudentpk);
		if (selectedStudent == null) {
		    throw new Exception("Student not found");
		}
		
		Order o = new Order();
		o.setStudentPk(selectedStudentpk);
		o.setOrderDate(LocalDateTime.now());
		o.setStatus("Pending");
		o = or.save(o);
		Long orderPk = o.getOrderPk();
		
		Retrofit retrofit = new Retrofit.Builder()
				.baseUrl("http://localhost:8080/")
				.addConverterFactory(GsonConverterFactory.create())
		        .build();
		
		MenuService menuService = retrofit.create(MenuService.class);
		double totalPrice = 0;
		for(OrderItemDTO item : orderDTO.getItems()) {
			
			Long foodItemPk = item.getFoodItemPk();
			int quantity = item.getOrderedQuantity();
			
			Call<FoodItem> foodCall = menuService.getFoodItem(foodItemPk);
			Response<FoodItem> reponse1 = foodCall.execute();
			FoodItem foodItem = reponse1.body();
			
			Call<Boolean> quantityCall = menuService.updateQuantity(foodItemPk, quantity);
			Response<Boolean> response2 = quantityCall.execute();
			Boolean updated = response2.body();
			
			OrderItem oi = new OrderItem();
			oi.setOrderPk(orderPk);
			oi.setFoodItemPk(foodItemPk);
			oi.setOrderedQuantity(quantity);
			oi.setItemPrice(foodItem.getPrice());
			oir.save(oi);
			double itemPrice = oi.getItemPrice();
			int orderedQuantity = oi.getOrderedQuantity();
			double orderItemPrice = itemPrice * orderedQuantity;
			totalPrice += orderItemPrice;
			o.setTotalPrice(totalPrice);
			
		}
		o = or.save(o);
		String message = "Hello " + selectedStudent.getName() + " your order has been received! You're total is " + o.getTotalPrice() + " pesos.";
		TwilioReply reply =  twilioComponent.sendSMS(selectedStudent.getCellphoneNumber(), message);
		Notification notification = new Notification();
		notification.setStudentPk(selectedStudentpk);
		notification.setOrderPk(orderPk);
		notification.setMessage(message);
		notification.setStatus("Sent");
		nr.save(notification);
		return reply;
	
	}

}
