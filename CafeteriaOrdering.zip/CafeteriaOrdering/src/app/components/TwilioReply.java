package app.components;




public class TwilioReply {
	private String body;
	private String to;
	private String status;
	private String messaging_service_sid;
	
	public String getMessageServiceId() {
		return messaging_service_sid;
	}
	public void setMessageServiceId(String messageServiceId) {
		this.messaging_service_sid = messageServiceId;
	}
	public String getBody() {
		return body;
	}
	public void setBody(String body) {
		this.body = body;
	}
	public String getTo() {
		return to;
	}
	public void setTo(String to) {
		this.to = to;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}

}
